スラスト・ロードスター PULSE 最終版

ZIPをすべて展開して index.html をブラウザーで開いてください。
PC: Space/↑で噴射、←→/A Dで移動、P/Escで一時停止。
スマートフォン:画面の操作ボタン。iPhoneのファイルプレビューで動かない場合は公開URLをSafariで開いてください。
音は発進などの操作後に有効になります。ポーズ画面でBGM・効果音・演出を調整できます。

公開URL: https://thrust-roadster-pulse.cuichunxue1984.chatgpt.site
3Dライブラリ同梱。Google Fontsは接続できない場合、端末のフォントで表示されます。
Three.js r128 / MIT license: three.min.js内のライセンス表記を参照。
